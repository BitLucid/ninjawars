<?php
//include('interface/header.php');
session_start();
import_request_variables("gP","");
include('../db/util.php');

$sql = new DBAccess();
$sql->Create("nw1");
?>
<style type="text/css">
<!--
a:link, a:active, a:visited {
color: #white;
text-decoration: none}

a:hover {
color: #4A265A;
text-decoration: underline}

BODY {
font : bold 10px/16px Verdana, Arial, Helvetica, sans-serif;
color : #FFFFFF;
}
TD {
font : bold 10px/16px Verdana, Arial, Helvetica, sans-serif;
color : #FFFFFF;
}
-->
</style>
<body bgcolor="#1E2A42">
<b><font color=red>Control Panel</font></b><p>
<form action="control.php" method="post">
<?php
$adminname = $_SESSION['adminname'];
if ($adminname != ""){

?>
 <small>Commands: <a href=control.php?command=Logout>Logout</a><br><br>
<b>Player Global:</b> <a href="control.php?command=AddPlayer">Add Player</a> |  <a href="control.php?command=DeletePlayer">Delete Player</a> | <a href="control.php?command=ViewAll">View All</a>  <br><br>
<b>Player Seperate:</b>  <a href="control.php?command=SetHealth">Set Health</a> | <a href="control.php?command=SetActive">Set Active</a> | <a href="control.php?command=SetPassword">Set Password</a> | <a href="control.php?command=SetStrength">Set Strength</a> | <a href="control.php?command=SetKills">Set Kills</a> | <a href="control.php?command=SetGold">Set Gold</a> | <a href="control.php?command=SetTurns">Set Turns</a>| <a href="control.php?command=SetClass">Set Class</a>| <a href="control.php?command=SetLevel">Set Level</a>
<br><br>
Item Control: <a href="control.php?command=AddItem">Add Item to Player</a><br>
<b>Mail:</b> <a href="control.php?command=MassEmail">Mass Email</a> <br>
<b>News:</b> <a href="control.php?command=ModifyNews">Modify News</a> <br>
<hr>
<?php

if ($command == "Logout")
   {
   echo "logging out";
   $_SESSION['adminname'] = "";
   }
if ($command == "MassEmail")
{
echo "Mass Email<br />";
echo "<table><form action='control.php' method='post'>";
echo '<tr>Subject</tr><tr><input type="textbox" name="subject"></tr>';
echo '<tr>Message</tr><tr><textarea name="msg"></textarea></tr>';
echo "<input type='hidden' name='process' value='1' style='font-family:Verdana, Arial;font-size:xx-small'>";
echo '<tr>Message</tr><tr><input type="submit" value="Send Mass Email"></tr>';
echo "</table></form>";
}
if ($command == "ViewAll")
{
   echo "<b>Viewing All Players</b>";
   echo "<table border='1'>";
   echo "<tr><td>Usr</td><td>Pwd</td><td>HP</td><td>Str</td><td>$$$</td><td>Msg</td><td>Kills</td><td>Turns</td><td>C</td><td>C1</td><td>@</td><td>Class</td><td>Lev</td></tr>";
   $sql->Query("select * from players");
	while ($data = $sql->Fetch())
	{
		$name = $data[0];
		$pass = $data[1];
		$hp = $data[2];
		$str = $data[3];
		$gold = $data[4];
		$msg = $data[5];
		$kills = $data[6];
		$turns = $data[7];
		$confirm = $data[8];
		$confirmed = $data[9];
		$email = $data[10];
		$cla = $data[11];
		$lev = $data[12];
   echo "<tr><td>$name</td><td>$pass</td><td>$hp</td><td>$str</td><td>$gold</td><td>$msg</td><td>$kills</td><td>$turns</td><td>$confirm</td><td>$confirmed</td><td>$email</td><td>$cla</td><td>$lev</td></tr>";
           }
   echo "</table>";
   }

if ($command == "SetHealth")
   {
   echo "<form action='control.php' method='post'>Set Health<br><br>";
   echo "<select name='Player' style='font-family:Verdana, Arial;font-size:xx-small'>";
                   echo "<option selected value=''>Pick a Name";
      $sql->Query("select * from players");
		while ($data = $sql->Fetch())
		{
			$name = $data[0];

			echo "<option value='$name'>$name";
		}
          echo "</select>";
   echo "<input type='text' name='new_value' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='command' value='SetHealth' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='process' value='1' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='submit' value='Set Health' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "</form>";
   if ($process == 1)
   {
       if ($Player == '') {die('No Player Selected');}
       echo "$Players's Health is now $new_value"; $sql->Update("update players set health = '$new_value' where uname = '$Player'");
       $affected_rows = $sql->a_rows;}

   }


if ($command == "SetStrength")
   {
   echo "<form action='control.php' method='post'>Set Strength<br><br>";
   echo "<select name='Player' style='font-family:Verdana, Arial;font-size:xx-small'>";
                   echo "<option selected value=''>Pick a Name";
      $sql->Query("select * from players");
		while ($data = $sql->Fetch())
		{
			$name = $data[0];

			echo "<option value='$name'>$name";
		}
          echo "</select>";
   echo "<input type='text' name='new_value' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='command' value='SetStrength' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='process' value='1' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='submit' value='Set Strength' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "</form>";
   if ($process == 1)
   {
       if ($Player == '') {die('No Player Selected');}
       echo "$Players's Strength is now $new_value"; $sql->Update("update players set strength = '$new_value' where uname = '$Player'");
       $affected_rows = $sql->a_rows;}

   }


   if ($command == "SetKills")
   {
   echo "<form action='control.php' method='post'>Set Kills<br><br>";
   echo "<select name='Player' style='font-family:Verdana, Arial;font-size:xx-small'>";
                   echo "<option selected value=''>Pick a Name";
      $sql->Query("select * from players");
		while ($data = $sql->Fetch())
		{
			$name = $data[0];

			echo "<option value='$name'>$name";
		}
          echo "</select>";
   echo "<input type='text' name='new_value' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='command' value='SetKills' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='process' value='1' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='submit' value='Set Kills' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "</form>";
   if ($process == 1)
   {
       if ($Player == '') {die('No Player Selected');}
       echo "$Players's Kills is now $new_value"; $sql->Update("update players set kills = '$new_value' where uname = '$Player'");
       $affected_rows = $sql->a_rows;}

   }


if ($command == "SetActive")
   {
   echo "<form action='control.php' method='post'>Set Active<br><br>";
   echo "<select name='Player' style='font-family:Verdana, Arial;font-size:xx-small'>";
                   echo "<option selected value=''>Pick a Name";
      $sql->Query("select * from players");
		while ($data = $sql->Fetch())
		{
			$name = $data[0];

			echo "<option value='$name'>$name";
		}
          echo "</select>";
   echo "<input type='text' name='new_value' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='command' value='SetActive' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='process' value='1' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='submit' value='Set Health' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "</form>";
   if ($process == 1)
   {
       if ($Player == '') {die('No Player Selected');}
       echo "$Players's Account is now $new_value"; $sql->Update("update players set health = '$new_value' where uname = '$Player'");
       $affected_rows = $sql->a_rows;}

   }


   if ($command == "SetPassword")
   {
   echo "<form action='control.php' method='post'>Set Password<br><br>";
   echo "<select name='Player' style='font-family:Verdana, Arial;font-size:xx-small'>";
                   echo "<option selected value=''>Pick a Name";
      $sql->Query("select * from players");
		while ($data = $sql->Fetch())
		{
			$name = $data[0];

			echo "<option value='$name'>$name";
		}
          echo "</select>";
   echo "<input type='text' name='new_value' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='command' value='SetPassword' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='process' value='1' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='submit' value='Set Password' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "</form>";
   if ($process == 1)
   {
       if ($Player == '') {die('No Player Selected');}
       echo "$Player Password is now $new_value"; $sql->Update("update players set pname = '$new_value' where uname = '$Player'");
       $affected_rows = $sql->a_rows;}

   }


   if ($command == "SetGold")
   {
   echo "<form action='control.php' method='post'>Set Gold<br><br>";
   echo "<select name='Player' style='font-family:Verdana, Arial;font-size:xx-small'>";
                   echo "<option selected value=''>Pick a Name";
      $sql->Query("select * from players");
		while ($data = $sql->Fetch())
		{
			$name = $data[0];

			echo "<option value='$name'>$name";
		}
          echo "</select>";
   echo "<input type='text' name='new_value' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='command' value='SetGold' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='process' value='1' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='submit' value='Set Gold' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "</form>";
   if ($process == 1)
   {
       if ($Player == '') {die('No Player Selected');}
       echo "$Player Gold is now $new_value"; $sql->Update("update players set gold = '$new_value' where uname = '$Player'");
       $affected_rows = $sql->a_rows;}

   }


   if ($command == "SetTurns")
   {
   echo "<form action='control.php' method='post'>Set Turns<br><br>";
   echo "<select name='Player' style='font-family:Verdana, Arial;font-size:xx-small'>";
                   echo "<option selected value=''>Pick a Name";
      $sql->Query("select * from players");
		while ($data = $sql->Fetch())
		{
			$name = $data[0];

			echo "<option value='$name'>$name";
		}
          echo "</select>";
   echo "<input type='text' name='new_value' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='command' value='SetTurns' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='process' value='1' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='submit' value='Set Turns' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "</form>";
   if ($process == 1)
   {
       if ($Player == '') {die('No Player Selected');}
       echo "$Player Turns set to $new_value"; $sql->Update("update players set turns = '$new_value' where uname = '$Player'");
       $affected_rows = $sql->a_rows;}

   }


   if ($command == "SetClass")
   {
   echo "<form action='control.php' method='post'>Set Class<br><br>";
   echo "<select name='Player' style='font-family:Verdana, Arial;font-size:xx-small'>";
                   echo "<option selected value=''>Pick a Name";
      $sql->Query("select * from players");
		while ($data = $sql->Fetch())
		{
			$name = $data[0];

			echo "<option value='$name'>$name";
		}
          echo "</select>";
   echo "<input type='text' name='new_value' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='command' value='SetClass' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='process' value='1' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='submit' value='Set Class' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "</form>";
   if ($process == 1)
   {
       if ($Player == '') {die('No Player Selected');}
       echo "$Player Class set to $new_value"; $sql->Update("update players set class = '$new_value' where uname = '$Player'");
       $affected_rows = $sql->a_rows;}

   }

 if ($command == "SetLevel")
   {
   echo "<form action='control.php' method='post'>Set Level<br><br>";
   echo "<select name='Player' style='font-family:Verdana, Arial;font-size:xx-small'>";
                   echo "<option selected value=''>Pick a Name";
      $sql->Query("select * from players");
		while ($data = $sql->Fetch())
		{
			$name = $data[0];

			echo "<option value='$name'>$name";
		}
          echo "</select>";
   echo "<input type='text' name='new_value' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='command' value='SetLevel' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='process' value='1' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='submit' value='Set Level' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "</form>";
   if ($process == 1)
   {
       if ($Player == '') {die('No Player Selected');}
       echo "$Player Level set to $new_value"; $sql->Update("update players set level = '$new_value' where uname = '$Player'");
       $affected_rows = $sql->a_rows;}

   }

if ($command == "AddPlayer")
   {
   if ($process == 1)
        {
         if  ($username != "" && $userpass != "") {
        //$sql->Insert("insert into players VALUES ('$username','$userpass','$health','$strength','$gold','','','','','')");
        $sql->Insert("insert into players VALUES ('$username','$userpass','150','5','50','','0','20','','$confirmed','$email','$class','$level')");
        $affected_rows = $sql->a_rows;
        echo "Player Added";
        }    else { "You left out information";}
        }

     echo "<form action='control.php' method='post'><hr>Adding Player<br><br>";

   echo "<table><tr>";

   echo "<tr><td>Username</td><td>Password</td><td>Health</td><td>Strength</td><td>Gold</td><td>Messages</td><td>Kills</td><td>Turns</td><td>Confirm</td><td>Confirmed</td><td>Email</td><td>Class</td><td>Level</td></tr>";
   echo "<tr>";
   echo "<td><input type='text' name='username' style='font-family:Verdana, Arial;font-size:xx-small'></td>";
   echo "<td><input type='text' name='userpass' style='font-family:Verdana, Arial;font-size:xx-small'></td>";
   echo "<td><input type='text' name='health' style='font-family:Verdana, Arial;font-size:xx-small'></td>";
   echo "<td><input type='text' name='strength' style='font-family:Verdana, Arial;font-size:xx-small'></td>";
   echo "<td><input type='text' name='gold' style='font-family:Verdana, Arial;font-size:xx-small'></td>";
   echo "<td><input type='text' name='messages' style='font-family:Verdana, Arial;font-size:xx-small'></td>";

   echo "<td><input type='text' name='kills' style='font-family:Verdana, Arial;font-size:xx-small'></td>";
   echo "<td><input type='text' name='turns' style='font-family:Verdana, Arial;font-size:xx-small'></td>";
   echo "<td><input type='text' name='confirm' style='font-family:Verdana, Arial;font-size:xx-small'></td>";
   echo "<td><input type='text' name='confirmed' style='font-family:Verdana, Arial;font-size:xx-small'></td>";
   echo "<td><input type='text' name='email' style='font-family:Verdana, Arial;font-size:xx-small'></td>";
   echo "<td><input type='text' name='class' style='font-family:Verdana, Arial;font-size:xx-small'></td>";
   echo "<td><input type='text' name='level' style='font-family:Verdana, Arial;font-size:xx-small'></td>";
   echo "</tr></table>";

   echo "<input type='hidden' name='process' value='1' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='hidden' name='command' value='AddPlayer' style='font-family:Verdana, Arial;font-size:xx-small'>";
   echo "<input type='submit' value='Add Player' style='font-family:Verdana, Arial;font-size:xx-small'>";
   }

   
if ($command == "DeletePlayer")
   {
      echo "<form action='control.php'>";
      echo "Deleting Player<br>";
        echo "<select name='DeletedPlayer' style='font-family:Verdana, Arial;font-size:xx-small'>";
        echo "<option selected value=''>Pick a Name";
      $sql->Query("select * from players");
		while ($data = $sql->Fetch())
		{
			$name = $data[0];

			echo "<option value='$name'>$name";
		}
          echo "</select>";
          echo "<input type='hidden' name='command' value='DeletePlayer' style='font-family:Verdana, Arial;font-size:xx-small'>";
          echo "<input type='hidden' name='process' value='1' style='font-family:Verdana, Arial;font-size:xx-small'>";
          echo "<input type='submit' value='Delete this Player' style='font-family:Verdana, Arial;font-size:xx-small'>";

   if ($process == 1)
        {
         if ($DeletedPlayer != "")
            {
            $sql->Delete("delete from players where uname = '$DeletedPlayer'");
            $affected_rows = $sql->a_rows;
            echo "<br>Player $username has been deleted";
            } else { echo "No Player was Selected";}
   }
}

}  // main if
else {
echo "<hr>You are not logged in";
}
?>

 <br><br><br><br><br><br><br><br><br><br><br><br>
<?php
//include('interface/footer.php');
?>

