<?php
$alive      = false;
$private    = false;
$quickstat  = false;
$page_title = "Multiplayers";

include "interface/header.php";

if (strtolower($username) =="tchalvak" or strtolower($username)=="glassbox" or strtolower($username)=="beagle" or strtolower($username)=="turtletower") //Security Requirement for viewing the page.
{

$command=$_GET['command'];   //Stage choosing command.
$ipInQuestion=$_GET['ipInQuestion'];  //Ip when a specific Ip link was clicked.
$userInQuestion=$_GET['userInQuestion'];   //The username when a specific user was clicked to be unconfirmed.
$limit = $_GET['limit'];   //  Gets a custom limit if necessary, from a ?limit=345 format
$userToCheck = $_GET['userToCheck'];   //Gets a player name to search for duplicate ips of.

if ($limit=="none")
	{
	$limit=" ";     // if I want there to be no limits for either statement
	}
else if ($limit)
{
	$limit="LIMIT ".$limit;   // formats the text of the limit
}
else if (!$limit) 
	{
	$limit="LIMIT 300";       //sets the default limit to 300
	}  
echo "LIMIT is: $limit <br />\n";
echo "<a href='AdminMultiplayers.php'>Return to full multi-ip list.</a><br />\n";

if (!$command)     // The default page, which shows the list of multi Ips.
{
	echo "<form action=\"AdminMultiplayers.php\" method=\"get\">\n";
	echo "<input type=\"textbox\" name=\"userToCheck\" style=\"font-family:Verdana, Arial;font-size:xx-small;\" />\n";
	echo "<input type=\"hidden\" name=\"command\" value=\"usernameSearch\" />\n";
	echo "<input type=\"submit\" class=\"formButton\" value=\"Search for a potential multiplayer by name.\" />\n";
	echo "</form>\n";
		echo "<form action=\"AdminMultiplayers.php\" method=\"get\">\n";
	echo "<input type=\"textbox\" name=\"ipInQuestion\" style=\"font-family:Verdana, Arial;font-size:xx-small;\" />\n";
	echo "<input type=\"hidden\" name=\"command\" value=\"ipDisplay\" />\n";
	echo "<input type=\"submit\" class=\"formButton\" value=\"Search for a potential multiplayer by IP.\" />\n";
	echo "</form>\n";
	
    echo "MULTI-IPS<br /><br />";
    //select count(*) AS c, ip from players group by ip HAVING count(ip)>1 ORDER BY c DESC;
	$sql->Query("SELECT count(*) AS c, ip FROM players WHERE confirmed = 1 GROUP  BY ip HAVING count(*) > 1 ORDER BY c DESC");
    echo "<a href='AdminMultiplayers.php?command=nullIpDisplay'>Click to view null ips.</a><br />\n";
    foreach ($sql->FetchAssociative() as $loopRow)
    {
        $count = $loopRow['c'];
        $multipleIp= $loopRow['ip'];
		echo "IP: <a href='AdminMultiplayers.php?command=ipDisplay&ipInQuestion=$multipleIp'>$multipleIp</a> Count: $count <br />\n";
    }

	if (($sql->a_rows)>298)
	{
		echo "<span style='color:red'>Limit of 300 reached.</span><br />\n";
	}
}
else if ($command=='usernameSearch' && !$userToCheck)  //If the search attempt is broken.
	{
	echo "Trying to search for null username.<br />\n";
	}
else if	($command=='usernameSearch' && $userToCheck)  //Searching by a specific username.
	{
		if (strlen($userToCheck) == 1)
		{
		  $where_clause = "WHERE (uname = '$userToCheck' OR uname LIKE '".strtoupper($userToCheck)."%' OR uname LIKE '".strtolower($userToCheck)."%')";
		}
	      else
		{
		  $where_clause = "WHERE (uname = '$userToCheck' OR uname LIKE '".strtoupper($userToCheck)."%' OR uname LIKE '".strtolower($userToCheck)."%')";
		}
	$selectStatement="SELECT ip, uname FROM players ".$where_clause." AND confirmed=1 ".$limit;
	echo "Full select statement: $selectStatement<br />";
	$results=mysql_query($selectStatement);
	$limitCount=0;
	while ($row	=mysql_fetch_array($results))  //Turns the results into the double array "row" over and over again.
		{
			echo "The user $row[1] has the IP $row[0].  To check this IP, click <a href=\"AdminMultiplayers.php?command=ipDisplay&ipInQuestion=$row[0]\">HERE</a>.<br />";
			$limitCount++;
		}
		echo "Limit Count: $limitCount<br />";
	if (!$row)
		{
		echo "No players by those names name found.<br />";
		}
		else if ($row[0])
		{
			if ($limitCount>298)
			{
				echo "Limit reached.<br />\n";
			}
		}
		else
		{
		echo "Error in the results.<br />\n";
		}
	}
else if (($command=='ipDisplay' && $ipInQuestion) || $command=='nullIpDisplay')   //the specific display section, which displays the results for a single ip
{
	if ($command=='nullIpDisplay')
	{
		$ipInQuestion=" ";
	}
	echo "SINGLE IP SPECIFICS for $ipInQuestion<br />";
	echo "<table>\n";
	echo "<tr style='font-weight:bold'><td>Ip</td><td>Username</td><td>P</td><td>Email</td><td>Level</td><td>Days</td><td>Clan</td><td>Confirmed?</td><td>Profile</td></tr>\n";
	$displayTableArray = $sql->Query("SELECT uname, pname, messages, email, level, days, ip, clan_long_name, confirmed"
	." FROM players"
	." WHERE confirmed=1"
	." AND ip='$ipInQuestion'"
	." ORDER BY days DESC $limit");
	for ($i=($sql->a_rows)-1;$i>=0;$i--)
	{
		$sql->Fetch($i);
		$multiUnameArray[$i]=$sql->data[0];
		$multiPname=$sql->data[1];
		$multiMessages=$sql->data[2];
		$multiEmail[$i]=$sql->data[3];
		$multiLevel=$sql->data[4];
		$multiDays=$sql->data[5];
		$multiIp=$sql->data[6];
		$multiClan=$sql->data[7];
		$multiConfirmed=$sql->data[8];
		echo "<tr><td> $multiIp </td><td><a href='AdminMultiplayers.php?command=unconfirm&userInQuestion=$multiUnameArray[$i]'>Unconfirm $multiUnameArray[$i]</a> </td><td> $multiPname </td><td> $multiEmail[$i] </td><td> Level: $multiLevel </td><td> Days: $multiDays </td><td> $multiClan </td><td> $multiConfirmed </td><td> Profile: $multiMessages </td><td></tr>\n";
	}
	echo "</table>\n";
	if (($sql->a_rows)>298)
	{
		echo "<span style='color:red'>Limit of 300 reached.</span><br />\n";
	}
	echo "<br /><a href='AdminMultiplayers.php?command=unconfirm&ipInQuestion=".$multiIp."'>Unconfirm all these multiplayers using the $multiIp IP!</a><br />\n";
}
else if ($command=="unconfirm"&&!$ipInQuestion&&!$userInQuestion)
	{
	echo "Attempting to unconfirm without an ip or a username, or with both of them at once.";
	}
else if ($command=="unconfirm"&&$ipInQuestion&&$userInQuestion)
	{
	echo "Attempting to unconfirm using both an IP and a username at once.";
	}
else if ($command=="unconfirm"&&$userInQuestion)  //Unconfirm and bann email by a single username.
	{
			$sql->QueryRow("SELECT email FROM players WHERE uname='$userInQuestion' AND confirmed=1 LIMIT 10");
		for ($i=($sql->a_rows)-1;$i>=0;$i--)
		{
			echo "<span style='color:red'>Banning Player $i :</span>";
			$sql->Fetch($i);
			$emailToUnconfirm[$i]=$sql->data[0];
			echo "$userInQuestion $emailToUnconfirm[$i] <br />\n";
			$bannedEmail = $emailToUnconfirm[$i]."BANNED"; 
			echo "$emailToUnconfirm[$i] email is turned into $bannedEmail and Confirmed is set to 0, LIMIT 1<br />"; 
			$sql->Update("UPDATE players SET confirmed=0 , email='$bannedEmail' WHERE uname='$userInQuestion' AND confirmed=1 LIMIT 1");
			// *** DEATH TO A SINGLE MULTIPLAYER OCCURS JUST ABOVE ! ***
		}

	}
else if ($command=="unconfirm"&&$ipInQuestion&&!$userInQuestion)        //Unconfirm and bann emails by a certain IP.
	{
		$result=mysql_query("SELECT uname, email FROM players WHERE ip='$ipInQuestion' AND confirmed=1 LIMIT 10");
		echo "LIMIT is 10<br />\n";
		print_r($result);
		echo "<br />";
		while ($data = mysql_fetch_array($result))
		{
			echo "<span style='color:red'>Banning Player $i :</span>";
			$playerToUnconfirm[$i]=$data[0];
			$emailToUnconfirm[$i]=$data[1];
			$bannedEmail[$i] = $emailToUnconfirm[$i]."BANNED"; 
			echo "$emailToUnconfirm[$i] email is turned into $bannedEmail[$i] and Confirmed is set to 0, just occurred.<br />";  
			$sql->Update("UPDATE players SET confirmed=0 , email='$bannedEmail[$i]' WHERE uname='$playerToUnconfirm[$i]' AND confirmed=1 LIMIT 1");
			//  *** DEATH TO A GROUP OF MULTIPLAYERS OCCURS JUST ABOVE! ***
		}
	}
else
{
	echo "Invalid command Error.";
}


}         //End of security requirement.
else 
{
	echo "Unsecured.";
}


include "interface/footer.php";
?>
