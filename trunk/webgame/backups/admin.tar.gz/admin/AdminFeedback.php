<?php
$private    = true;
$alive      = false;
$quickstat  = false;
$page_title = "Admin Feedback";
include "interface/header.php";
?>

<span class="brownHeading">List of Administrative Statistical Feedback</span>

<br /><br />

<?php

if ($username=="tchalvak" || $username=="glassbox")
{
	echo "<br />SECURED SECTION<br />";
	$maxGold=$sql->QueryRow("SELECT max(gold) FROM players WHERE confirmed=1");
	$mostGoldPlayer=$sql->QueryRow("SELECT uname FROM players WHERE confirmed=1 AND gold=".$maxGold[0]);
	echo "The most gold held by any one player is $maxGold[0] in the hands of $mostGoldPlayer[0]<br />";
	$totalKills=$sql->QueryRow("SELECT sum(kills) FROM players WHERE confirmed=1");
	echo "The total number of kills is: $totalKills[0]<br />";
	$maxKills=$sql->QueryRow("SELECT max(kills) FROM players WHERE confirmed=1");
	$mostKillsPlayer=$sql->QueryRow("SELECT uname FROM players WHERE confirmed=1 AND kills=".$maxKills[0]);
	echo "The most kills held by any one player is $maxKills[0] in the hands of $mostKillsPlayer[0]<br /><br />";
	/*   This one is kinda complicated to pull off, and probably slow.
	echo "<br />IPs<br />\n";
	$duplicateIps=$sql->QueryRow("SELECT uname FROM players WHERE ip GROUP BY ip DESC
	*/
	
	$mostKillsTodayResults = mysql_query("SELECT max(killpoints) FROM levelling_log WHERE killsdate=CURRENT_TIMESTAMP");
	while ($rows =mysql_fetch_array($mostKillsTodayResults, MYSQL_NUM))
	{
		echo "ZZZZZZZZRows1 ".$rows[0]." Rows2 ".$rows[1]."<br />\n";
		printf("Max kills gained today: %s Rows2 %s", $rows[0], $rows[1]);
	}
	$affectedRows=mysql_num_rows($mostKillsTodayResults);
	echo " Affected Rows: $affectedRows The most kills today are $rows[0], held by $rows[1].<br />";


	$mostLevelsTodayResults = mysql_query("SELECT max(levelling) FROM levelling_log WHERE killsdate=CURRENT_TIMESTAMP");
	while ($rows =mysql_fetch_array($mostLevelsTodayResults, MYSQL_NUM))
	{
		printf("Max levels gained today: %s Rows2 %s", $rows[0], $rows[1]);
	}
	$affectedRows=mysql_num_rows($mostLevelsTodayResults);
	echo " Affected Rows: $affectedRows The most kills today are $rows[0], held by $rows[1].<br />";

}
else 
{
	echo "NOT SECURED.";
}

//*  Toggle On/Off

$healthOverResurrect=$sql->QueryRow("SELECT count(*) FROM players WHERE confirmed=1 AND health>150");
echo "<br />Number of players who have healed themselves over 150 hitpoints: $healthOverResurrect[0]<br />\n";
$maxHealth=$sql->QueryRow("SELECT max(health) FROM players WHERE confirmed=1");
$mostHealthPlayer=$sql->QueryRow("SELECT uname FROM players WHERE confirmed=1 AND health=".$maxHealth[0]);
echo "The most health of any one player is $maxHealth[0] in the hands of $mostHealthPlayer[0]<br />";

echo "<br />Gold<br />\n";
$goldTotal=$sql->QueryRow("SELECT sum(gold) FROM players WHERE confirmed=1");
$negativeGoldTotal=$sql->QueryRow("SELECT count(*) FROM players WHERE gold<0");
echo "The total amount of gold carried by players is $goldTotal[0] and total players with negative gold is: $negativeGoldTotal[0]<br />";

$classArray[0]="Red";
$classArray[1]="White";
$classArray[2]="Blue";
$classArray[3]="Black";

$totalPlayerCount=$sql->QueryRow("SELECT count(*) from players WHERE confirmed=1");
echo "Total Confirmed Players: $totalPlayerCount[0]<br /><br />\n";

echo "Total Live Class Distribution<br />\n";
foreach ($classArray as $className)
{
	$classCount=$sql->QueryRow("Select count(*) from players WHERE class='$className' AND confirmed=1");
	echo "There are $classCount[0] Confirmed $className Ninja.<br />\n";
}
echo "<br /><br />Live Class Distribution under level 20<br />\n";
foreach ($classArray as $className)
{
	$classCount=$sql->QueryRow("Select count(*) from players WHERE class='$className' AND confirmed=1 AND level<20");
	echo "There are $classCount[0] Confirmed $className Ninja.<br />\n";
}
echo "<br /><br />Live Class Distribution level 20 and above<br />\n";
foreach ($classArray as $className)
{
	$classCount=$sql->QueryRow("Select count(*) from players WHERE class='$className' AND confirmed=1 AND level>19");
	echo "There are $classCount[0] Confirmed $className Ninja.<br />\n";
}

$totalSignupCount=$sql->QueryRow("SELECT count(*) from players WHERE 1");
echo "<br /><br />Total Signups: $totalSignupCount[0]\n";
echo "<br /><br />Total Class Distribution for all Signups<br />\n";
foreach ($classArray as $className)
{
	$classCount=$sql->QueryRow("Select count(*) from players WHERE class='$className'");
	echo "There are $classCount[0] players that chose $className Ninja.<br />\n";
}
$totalSignupsToday=$sql->QueryRow("SELECT count(*) from players WHERE confirmed=0 AND days=0");
echo "<br />Total Signups since midnight last night: $totalSignupsToday[0]<br />\n";
$totalTwoDaySignups=$sql->QueryRow("SELECT count(*) FROM players WHERE confirmed=0 AND days<2");
echo "Total Unconfirmed Signups in the past two days: $totalTwoDaySignups[0]<br />\n";
$weeklySignups=$sql->QueryRow("SELECT count(*) FROM players WHERE confirmed=0 AND days<7");
echo "Total Unconfirmed Signups this week: $weeklySignups[0] and Resulting Daily Average: ".round($weeklySignups[0]/7, 2)."<br />\n";
$currentNewbies=$sql->QueryRow("SELECT count(*) FROM players WHERE gold=50 AND days=0");
echo "Current Newbies that still have 50 gold: $currentNewbies[0] <br />\n";

$totalLoginsToday=$sql->QueryRow("SELECT count(*) FROM players WHERE confirmed=1 AND days=0");
$totalWeeklyPlayers=$sql->QueryRow("SELECT count(*) FROM players WHERE confirmed=1 AND days<7");
echo "<br />Logins Today: $totalLoginsToday[0] , this week: $totalWeeklyPlayers[0] and the resulting daily average: ".round($totalWeeklyPlayers[0]/7, 2)."<br />\n";
for ($i=0;$i<61;$i=$i+5)
{
	$confirmedPlayers=$sql->QueryRow("SELECT count(*) FROM players WHERE confirmed=1 AND days<=$i");
	echo "Confirmed players logged in past $i days: $confirmedPlayers[0]<br />";
}
$notFirstLevelLogins=$sql->QueryRow("SELECT count(*) FROM players WHERE confirmed=1 AND days=0 AND level>1");
$notFirstLevelWeeklyLogins=$sql->QueryRow("SELECT count(*) FROM players WHERE confirmed=1 AND days<7 AND level>1");
echo "<br />Logins of players over level One: $notFirstLevelLogins[0], this week: $notFirstLevelWeeklyLogins[0] and the resulting daily average: ".round($notFirstLevelWeeklyLogins[0]/7, 2)."<br /><br />\n";

for ($i=0;$i<20;$i++)
{
	$levelTally=$sql->QueryRow("SELECT count(*) FROM players WHERE confirmed=1 AND level=$i");
	if ($levelTally[0]>0)
	{
		echo "| Players at Level $i: $levelTally[0] |<br />\n";
	}
}
for ($i=20;$i<151;$i=$i+5)
{
	$levelTally=$sql->QueryRow("SELECT count(*) FROM players WHERE confirmed=1 AND (level BETWEEN $i AND ".($i+4).")");
	if ($levelTally[0]>0)
	{
		echo "| Players between Level $i and ".($i+4).": $levelTally[0] |<br />\n";
	}
}

$itemArray[0]="Dim Mak";
$itemArray[1]="Stealth Scroll";
$itemArray[2]="Ice Scroll";
$itemArray[3]="Fire Scroll";
$itemArray[4]="Shuriken";

$totalItems=$sql->QueryRow("SELECT count(*) FROM inventory WHERE 1");
echo "<br />Total Items: $totalItems[0]<br /><br />\n";
foreach ($itemArray as $itemName)
{
	$itemCount=$sql->QueryRow("SELECT count(*) FROM inventory WHERE item='$itemName'");
	echo "There are $itemCount[0] $itemName among all the players.<br />\n";
}
$emptyItemTotal=$sql->QueryRow("SELECT count(*) FROM inventory WHERE item=''");
$playerlessItemTotal=$sql->QueryRow("SELECT count(*) FROM inventory WHERE owner=''");
echo "Total empty items: $emptyItemTotal[0] and playerless items: $playerlessItemTotal[0]<br />\n";


echo "<br />Messages<br />\n";
$messageTotal=$sql->QueryRow("SELECT count(*) FROM mail WHERE 1");
$emptyMessageTotal=$sql->QueryRow("SELECT count(*) FROM mail WHERE message=''");
$targetlessMessageTotal=$sql->QueryRow("SELECT count(*) FROM mail WHERE send_to=''");
$senderlessMessageTotal=$sql->QueryRow("SELECT count(*) FROM mail WHERE send_from=''");
echo "The total messages in players inboxes is $messageTotal[0], the empty messages total is: $emptyMessageTotal[0], the senderless message total is: $senderlessMessageTotal[0], and the targetlessMessageTotal is: $targetlessMessageTotal[0]<br />";

//*/
/*



if (!$mail_list_length)
{
	$mail_list_length = 20;
}

$sql->QueryRow("SELECT * FROM mail WHERE send_to = 'NewUserList' ORDER BY id DESC LIMIT $mail_list_length");
$row = $sql->data;

echo "<span style=\"font-weight: bold\">Inbox</span>\n";
echo "<form id=\"mail_delete\" action=\"mail_delete.php\" method=\"POST\" name=\"mail_delete\">\n";
echo "Viewing Messages: 1-".$sql->rows."<br />\n";
echo "<input id=\"DeleteSelected\" type=\"submit\" value=\"Delete Selected\" name=\"DeleteSelected\" class=\"formButton\" />\n";
echo "<input id=\"DeleteAll\" type=\"submit\" value=\"Delete All\" name=\"DeleteAll\" class=\"formButton\" />\n";
echo "<hr />\n";


if ($sql->rows == 0)
{
  echo "You have no messages.\n";
}
else
{
  echo "(Click on a Ninja's name to Send a Reply Msg.)<br />\n";
  echo "<table style=\"border:1 solid #000000;\">\n";
  echo "<tr>\n";
  echo "  <th>\n";
  echo "  Delete\n";
  echo "  </th>\n";
  
  echo "  <th>\n";
  echo "  From\n";
  echo "  </th>\n";
  
  echo "  <th>\n";
  echo "  Message\n";
  echo "  </th>\n";
  echo "</tr>\n";
  
  for ($i = 0; $i < $sql->rows; $i++)
    {
      $sql->Fetch($i);
      $id      = $sql->data[0];
      $from    = $sql->data[1];
      $to      = $sql->data[2];
      $message = $sql->data[3];
      
      echo "<tr>\n";
      echo "  <td valign=\"top\" style=\"text-align: center;\">\n";
      echo "  <input type=\"checkbox\" name=\"mailID[$i]\" value=\"$id\" />\n";
      echo "  </td>\n";
      
      echo "  <td valign=\"top\">\n";
      echo "  <a href=\"player.php?player=$from\">$from</a>\n";
      echo "  </td>\n";
	  
      echo "  <td>\n";
      echo    $message."\n";
      echo "  </td>\n";
      echo "</tr>\n";
    }
  
  echo "</table>\n";
}

echo "</form>\n";

if ($mail_list_length < 200 && $sql->rows != 0 && $i == 20)
{
	echo "<a href=\"NewUserList.php?mail_list_length=200\">View Older Mail</a><br />\n";
}

*/

include "interface/footer.php";
?>
