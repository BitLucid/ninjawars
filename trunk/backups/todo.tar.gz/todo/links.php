<?php
$alive      = false;
$private    = false;
$quickstat  = false;
$page_title = "Links";

include "interface/header.php";
?>

<span class="brownHeading">Links</span>

<p>

<a href="http://www.entertheninja.com" target="_blank"><img src="http://www.entertheninja.com/banners/468x60_etn_ordie.gif" style="border:  0;" /></a>
<a href="http://entertheninja.com/store.shtml" target="_blank"><img src="http://www.entertheninja.com/banners/468x60_etnwear_najin.gif" style="border:  0;" /></a>
<a href="http://www.ultimatemartialarts.net/" target="_blank"><img src="http://entertheninja.com/banners/martialartsnet_408x60.gif" style="border:  0;" /></a>
<hr />

</p>

<?php
include "interface/footer.php";
?>

