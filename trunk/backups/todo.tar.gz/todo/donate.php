<?php
$alive      = false;
$private    = false;
$quickstat  = false;
$page_title = "Support NinjaWars";

include "interface/header.php";
?>

<span class="brownHeading">Donations: Questions ? Contact <a href="staff.php">Staff</a></span>

<p>

<a href="https://www.paypal.com/xclick/business=jkfacey%40fastmail.fm&item_name=Ninja+Wars&item_number=100&no_note=1&tax=0&currency_code=USD" target="_blank" style="font-weight: bold;">Make a Donation</a><br />

Click Above to Donate Money to Ninja Wars.<br />

<br /><br />

Below this point is not quite working yet<br /><br />

<hr />

<a href="https://www.paypal.com/xclick/business=jkfacey%40fastmail.fm&item_name=Ninja+Wars+Turns&item_number=101&amount=1.00&no_note=1&currency_code=USD" target="_blank">Buy Turns</a><br />

You will receive 5 turns per dollar. NOTE: This process is not automated yet.

<hr /><br /><br />

Want to play as a Thief, want to change you Ninja Type as well. You need to get a paid membership.

<br />

Still working out Yearly vs Lifetime(one payment) subscription<br />
Subscription feature comming soon.

</p>

<?php
include "interface/footer.php";
?>

