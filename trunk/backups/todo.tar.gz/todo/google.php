<?php
$alive      = false;
$private    = false;
$quickstat  = false;
$page_title = "Google Ads";

include "interface/header.php";
?>

<script type="text/javascript">
<!--
google_ad_client = "pub-5315490719022958";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
//-->
</script>
<div style="text-align: center;">
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
google_color_border = "003366";
google_color_bg     = "000000";
google_color_link   = "FFFFFF";
google_color_url    = "FF6600";
google_color_text   = "FF6600";
</script>
</div>
<span style="color: #333333;font-size: 4px;">
Ninja 
Samurai
Shogun
Sword
Martial Arts
Skill
Magic
Web Games
MMORPG
MMOPG
MMOG
BBG
Multi Player
Katana
Star
Fire
Ice
Thief
Role Playing
Lord
Stealth
Dagger
Shuriken
War
Combat
China
Japan
</span>

<?php
include "interface/footer.php";
?>
